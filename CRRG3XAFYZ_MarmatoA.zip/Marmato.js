let Div_container = document.getElementById("root");
let searchInputEl = document.getElementById("search");
let NewEdition_img_Element = document.getElementById("new-edition");
let Shirts_Image_Element = document.getElementById("shitrs");
let Hoodies_Image_Element = document.getElementById("hoodies1");
let NewEdition_title_Element = document.getElementById("p1");
let Shitrs_title_Element = document.getElementById("p2");
let Hoodies_title_Elemnt = document.getElementById("p3");
let Latest_Edition_container = document.getElementById("1");
let Shirt_items_container = document.getElementById("2");
let Hoodies_items_container = document.getElementById("3");

function displayApiData(jsonData) {
    console.log(jsonData);
    for (let i = 0; i < jsonData.length; i++) {
        if (i === 0) {
            NewEdition_img_Element.src = jsonData[i].image;
            NewEdition_img_Element.alt = jsonData[i].title;
            NewEdition_title_Element.textContent = jsonData[i].title;
        } else if (i === 1) {
            Shirts_Image_Element.src = jsonData[i].image;
            Shirts_Image_Element.alt = jsonData[i].title;
            Shitrs_title_Element.textContent = jsonData[i].title;
        } else if (i === 2) {
            Hoodies_Image_Element.src = jsonData[i].image;
            Hoodies_Image_Element.alt = jsonData[i].title;
            Hoodies_title_Elemnt.textContent = jsonData[i].title;
        }


    }

}



function getApidata(searchInput) {

    let url = `https://products-api-2ttf.onrender.com/api/products`;
    let options = {
        method: "GET",

    };
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {

            displayApiData(jsonData);

        });

}


function onChangeSearchInput(event) {
    let search_user_input = event.target.value;
    getApidata(search_user_input);

}
getApidata();

searchInputEl.addEventListener("keyup", onChangeSearchInput);